Phonics Garden 1.1.0 — original recording sources

This archive contains the exact selected upstream OGG/WAV recordings,
attribution, license texts, hashes, and a standalone conversion script.
It does not claim to contain the recordists' unavailable studio masters.
Audio assets retain their individual licenses. No GCompris application
code is incorporated. The independent H5 application is not included.

Run: python3 rebuild-audio.py
Requirements: Python 3 and FFmpeg with libmp3lame. No network needed.
Output: rebuilt/en-us/*.mp3 and rebuilt/en-gb/*.mp3.
The command encodes MP3 at 96 kbit/s with no trimming, normalization,
speed change, pitch shift, denoising, or concatenation. Different
FFmpeg versions can produce different encoded-byte hashes.
