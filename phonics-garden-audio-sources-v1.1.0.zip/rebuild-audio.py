#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'manifest.json').read_text())
for clip in manifest['assets']:
    relative = clip['originalPath'].removeprefix('assets/original-audio/')
    source = root / relative
    if not source.resolve().is_relative_to(root):
        raise ValueError('Source path escapes archive')
    if hashlib.sha256(source.read_bytes()).hexdigest() != clip['originalSha256']:
        raise ValueError('Original recording hash mismatch: ' + relative)
    output = root / 'rebuilt' / clip['locale'] / (clip['key'] + '.mp3')
    output.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', str(source),
                    '-codec:a', 'libmp3lame', '-b:a', '96k', '-map_metadata', '-1',
                    str(output)], check=True)
print('Rebuilt', len(manifest['assets']), 'MP3 files from verified originals.')
